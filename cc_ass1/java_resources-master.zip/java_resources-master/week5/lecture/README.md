### Java Week 5 Lecture Resources

This folder contains the Java source code (under ```src``` ) and ant build file of a two job MapReduce program. The program simulate a select-join analysis of two input files.

The first input file contains place information with the following format:

```
place_id \t woeid \t lat \t longi \t place_name \t place_url
```
You have used a file of this format (*place.txt*) in week 4 tutorial.

The second input file contains photo information with the following format:

```
photo_id \t owner \t tags \t date_taken \t place_id \t accuracy
```
You have used a file of this format (*partial.txt*) in week 4 tutorial.

The program aims to find out all photos taken in a given country, where the country name is supplied as online argument.
The program is implemented as two MapReduce jobs.

The first job extracts all rows from the place input file containing a given country name in place_url field. If no coutry code is given, the default one "Australia" will be used. This job only requires a map phase, hence only the mapper code is provided: *PlaceFilterMapper.java*. The output of this job is a list of key-value pairs of the format 

```
place_id  "\t"  place_url
```
The output is writted to a temporary output location: "tmpFilterOut". The location is specified in the driver program
*JobChainDriver.java*:
```
Path tmpFilterOut = new Path("tmpFilterOut")
TextOutputFormat.setOutputPath(placeFilterJob, tmpFilterOut);
```

The second job (*ReplicateJoinMapper.java*) is also a map-only job. It joins the output of the first job with the photo input file on field *place_id* and output a list of record of the following format:
```
photo_id \t date_taken \t place_url
```

The two jobs are chained in the driver program *JobChainDriver.java*. It showcase the following features:

 
* Share simple variable among all mappers as configuration property . e.g.

	```java
	conf.set("mapper.placeFilter.country", otherArgs[3]);
	```
	
	This property is read by *PlaceFilterMapper.java* 
	```java
	countryName = context.getConfiguration().get("mapper.placeFilter.country", countryName);
	```
* Share small file among all mappers using distributed cache. E.g.
	```java
	DistributedCache.addCacheFile(new Path("tmpFilterOut/part-m-00000").toUri(),joinJob.getConfiguration());
	```
	The files are access by *ReplicateJoinMapper.java* in the setup method:
	
	```java
	Path[] cacheFiles = DistributedCache.getLocalCacheFiles(context.getConfiguration());
	```
* Indicat map-only job by setting reducer number to 0. e.g.
	```java
	placeFilterJob.setNumReduceTasks(0);
	```
* chain and automatically execute multiple jobs by creating multiple jobs in the driver and submit them one by one
	```java
	Job placeFilterJob = new Job(conf, "Place Filter");
	...
	placeFilterJob.waitForCompletion(true);
	Job joinJob = new Job(conf, "Replication Join");
	joinJob.waitForCompletion(true);
	remove the temporary path
	FileSystem.get(conf).delete(tmpFilterOut, true);
	```

