package comp5349.mrsim;

import java.util.*;

/**
 * Example Reducer that averages the Integers in the values.
 *
 */
public class RatingReducer implements Reducer<String, Integer, Float> {

	@Override
	public Float reduce(String key, List<Integer> values) {
		// reduce method to be done
		return null;
	}
}
