package usertag;

public class filterID {
    private String video_id;
    private String category;
    private String country;


    public filterID(String video_id, String category, String country){
        this.video_id=video_id;
        this.category=category;
        this.country=country;
    }

    private String getId(){
        return video_id;
    }

    private String getCategory(){
        return category;
    }

    private String getCountry(){
        return country;
    }

    private String setCountry(String cy){
        country=cy;
    }

}