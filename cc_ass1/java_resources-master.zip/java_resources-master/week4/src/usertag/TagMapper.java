package usertag;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import /Users/luoshanshan/Desktop/5349cc/java_resources-master/week4/src/usertag/filterID;

/**
 * input record format
 * 2048252769	48889082718@N01	dog francis lab	2007-11-19 17:49:49	RRBihiubApl0OjTtWA	16
 * 
 * output key value pairs for the above input
 * dog -> 48889082718@N01
 * francis -> 48889082718@N01
 * 
 * @author Ying Zhou
 *
 */
public class TagMapper extends Mapper<Object, Text, Text, Text> {
	

	

	private Text word = new Text(),owner = new Text();

	
	// a mechanism to filter out non ascii tags
	static CharsetEncoder asciiEncoder = Charset.forName("US-ASCII").newEncoder(); 
	
	public void map(Object key, Text value, Context context
	) throws IOException, InterruptedException {
		
		String[] dataArray = value.toString().split("\t"); //split the data into array
		if (dataArray.length < 5){ //  record with incomplete data
			return; // don't emit anything
		}


		String video_id=dataArray[0];
		String category=dataArray[3];
		String country=dataArray[11];

		private filterID n_data= new filterID(video_id, country, category);

		ArrayList<filterID> n_list= new ArrayList<filterID>();
		
		n_list.add(n_data);

		//这里 我假定所有的arraylist里面的东西都存进去了
		for (int i=0; i<n_list.length; i++){
			for (int j=0; j<n_list.length; j++){
				if(a.getID.equals(b.getID)){
					a.setCountry(a.getCountry+"_"+b.getCountry);
					n_list.remove(j);
				}
			}
		}


		
		
		
		
		//generate the same video_id
		String[]id_wanted =video_id.split(" ")
		for(int i=0; i<id_wanted.length; i++){
			for(int j=0; j<id_wanted.length; j++){
				if(id_wanted[i]==id_wanted[j]){
					
				}
			}
		}

		//count the country number

		

		if (tagString.length() > 0){
			String[] tagArray = tagString.split(" ");
			for(String tag: tagArray) {
				if (asciiEncoder.canEncode(tag)){
					word.set(tag);
					owner.set(ownerString);
					context.write(word, owner);
				}
			}
		}
	}
}
