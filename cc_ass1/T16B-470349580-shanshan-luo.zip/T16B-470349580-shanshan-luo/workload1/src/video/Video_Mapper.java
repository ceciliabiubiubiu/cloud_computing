package video;



import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class Video_Mapper extends Mapper<Object, Text, Text, Text> {




        // a mechanism to filter out non ascii tags
        static CharsetEncoder asciiEncoder = Charset.forName("US-ASCII").newEncoder();

        public void map(Object key, Text value, Context context
        ) throws IOException, InterruptedException {

                String[] dataArray = value.toString().split(","); //split the data into array
                if (dataArray.length < 12 || dataArray[0].equals("video_id")){ //  record with incomplete data
                        return; // don't emit anything
                }


                String video_id_country_str=dataArray[0]+","+dataArray[11];
                String category_str=dataArray[3];
                Text video_id_country=new Text(video_id_country_str);
                Text category=new Text(category_str);

                context.write(category, video_id_country);
        }

}

