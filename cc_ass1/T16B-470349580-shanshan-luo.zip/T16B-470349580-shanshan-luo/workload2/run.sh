export PYSPARK_PYTHON='python3'



spark-submit \
   --master local[4] \
   Driver.py \
   --input $1 \
   --output $2/
